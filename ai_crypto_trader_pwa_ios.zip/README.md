# AI Crypto Trader — iOS PWA

Bu sürüm mevcut Expo ekranının Safari/iPhone uyumlu PWA karşılığıdır.

## iPhone'a kurulum
1. Bu klasörü HTTPS ile yayınlayın (GitHub Pages, Netlify veya Vercel gibi).
2. iPhone'da Safari ile siteyi açın.
3. Paylaş → Ana Ekrana Ekle.
4. Ana ekrandaki AI Crypto Trader ikonuna dokunun. Uygulama standalone/tam ekran açılır.

## Backend
Uygulama ilk açılışta demo/paper verisi kullanır. Ayarlar bölümüne HTTPS backend adresinizi yazarsanız `/api/status` endpoint'inden veri çeker.
Tarayıcıdan HTTPS sayfadan HTTP backend'e bağlanmak mixed-content nedeniyle engellenebilir.

## Güvenlik
Bu PWA gerçek Binance API anahtarlarını istemez ve mevcut sürüm gerçek emir açmaz. API anahtarları istemci tarafına koyulmamalıdır.
